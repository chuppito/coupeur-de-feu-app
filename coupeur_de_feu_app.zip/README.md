# Suivi Coupeur de Feu

Application Flutter de suivi de patients pour une pratique de coupeur de feu :
fiches patients, zones du corps associées à des problématiques, stockage
100% local via Hive.

## Installation

```bash
cd coupeur_de_feu_app
flutter pub get
flutter run
```

Aucune étape de génération de code (`build_runner`) n'est nécessaire : l'adaptateur
Hive (`PatientModelAdapter`) est écrit à la main dans `lib/models/patient_model.dart`.

## Architecture

Clean Architecture simplifiée, organisée par responsabilité :

```
lib/
 ├── main.dart                     # Point d'entrée, init Hive + Provider
 ├── models/
 │    ├── patient_model.dart       # Modèle + TypeAdapter Hive (fiche patient)
 │    └── symbolique_model.dart    # Modèle de signification symbolique
 ├── data/
 │    ├── body_zones_data.dart     # Liste statique des zones du corps
 │    └── symboliques_data.dart    # Map statique zone -> symbolique/conseils
 ├── services/
 │    └── hive_service.dart        # Initialisation & accès à la box Hive
 ├── providers/
 │    └── patient_provider.dart    # État + logique métier (CRUD patients)
 ├── widgets/
 │    ├── body_zone_selector.dart  # GridView de sélection de zone
 │    └── patient_list_item.dart   # Item de la liste d'accueil
 └── screens/
      ├── home_screen.dart             # Liste des patients
      ├── create_patient_screen.dart   # Création / édition de fiche
      └── patient_detail_screen.dart   # Consultation + symbolique
```

## Fonctionnalités

- **Écran d'accueil** : liste des fiches patients (tri par date décroissante),
  suppression avec confirmation.
- **Création de fiche** : nom, date, sélection de zone du corps (grille de
  boutons), sliders d'intensité avant/après (0-10), observations libres.
- **Consultation de fiche** : récapitulatif de la fiche + signification
  symbolique et conseils associés à la zone sélectionnée (données statiques,
  éditables dans `lib/data/symboliques_data.dart`), édition possible.

## Aller plus loin

- Étendre `bodyZones` et `symboliquesData` selon votre pratique.
- Ajouter une recherche/filtre sur l'écran d'accueil.
- Exporter les fiches en PDF.
- Chiffrer la box Hive (`Hive.openBox` supporte une clé de chiffrement) si les
  données patients doivent être protégées davantage.
