import 'package:flutter/foundation.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../models/patient_session.dart';

/// Gère la persistance des séances patient via Hive.
/// Remplace l'ancienne implémentation SharedPreferences/JSON :
/// Hive était déjà initialisé dans main.dart mais n'était pas utilisé,
/// pendant que SharedPreferences stockait les données en parallèle.
/// Il n'y a maintenant qu'une seule source de vérité.
class HistoryService {
  static Box<PatientSession> get _box => Hive.box<PatientSession>('sessions');

  /// Permet d'écouter les changements de la box (utilisé par
  /// ValueListenableBuilder pour rafraîchir l'UI automatiquement).
  static ValueListenable<Box<PatientSession>> listenable() =>
      _box.listenable();

  static Future<void> saveEntry(
    String nom,
    String maladie,
    String zones, {
    String observation = '',
    int intensiteAvant = 0,
    int intensiteApres = 0,
  }) async {
    final session = PatientSession(
      nomPatient: nom,
      maladie: maladie,
      zone: zones,
      observation: observation,
      intensiteAvant: intensiteAvant,
      intensiteApres: intensiteApres,
      date: DateTime.now(),
    );
    await _box.add(session);
  }

  static List<PatientSession> getHistory() {
    final list = _box.values.toList();
    list.sort((a, b) => b.date.compareTo(a.date)); // plus récent en premier
    return list;
  }

  static Future<void> renamePatient(String oldName, String newName) async {
    final concernes = _box.values.where((s) => s.nomPatient == oldName);
    for (final session in concernes) {
      session.nomPatient = newName;
      await session.save();
    }
  }

  static Future<void> deletePatient(String nom) async {
    final aSupprimer =
        _box.values.where((s) => s.nomPatient == nom).toList();
    for (final session in aSupprimer) {
      await session.delete();
    }
  }

  /// Marque (ou démarque) une séance comme guérie, en horodatant le moment
  /// de la validation.
  static Future<void> toggleGuerison(PatientSession session) async {
    session.guerie = !session.guerie;
    session.dateGuerison = session.guerie ? DateTime.now() : null;
    await session.save();
  }

  /// Ajoute ou modifie la note libre associée à une séance.
  static Future<void> updateObservation(PatientSession session, String note) async {
    session.observation = note;
    await session.save();
  }
}
