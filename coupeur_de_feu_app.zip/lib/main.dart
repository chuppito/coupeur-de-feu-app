import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'models/patient_session.dart';
import 'screens/home_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Hive.initFlutter();
  Hive.registerAdapter(PatientSessionAdapter());
  await Hive.openBox<PatientSession>('sessions');
  runApp(const MyApp()); // Ajout de 'const' ici
}

class MyApp extends StatelessWidget {
  const MyApp({super.key}); // Ajout de 'const' ici
  
  @override
  Widget build(BuildContext context) {
    return const MaterialApp(home: HomeScreen()); // Ajout de 'const' ici
  }
}