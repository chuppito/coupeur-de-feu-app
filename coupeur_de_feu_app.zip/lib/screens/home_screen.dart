import 'package:flutter/material.dart';
import '../data/symbolique_data.dart';
import '../services/history_service.dart';
import '../widgets/interactive_body.dart';
import 'history_screen.dart';

class HomeScreen extends StatefulWidget {
  final String? prefillNom;
  const HomeScreen({super.key, this.prefillNom});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String? _selectedMaladie;
  final Set<String> _selectedZones = {};
  late TextEditingController _nomController;

  @override
  void initState() {
    super.initState();
    _nomController = TextEditingController(text: widget.prefillNom ?? "");
  }

  @override
  void dispose() {
    _nomController.dispose();
    super.dispose();
  }

  void _onZoneTap(String zone) {
    setState(() {
      if (_selectedZones.contains(zone)) {
        _selectedZones.remove(zone);
      } else {
        _selectedZones.add(zone);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Coupeur de Feu"),
        actions: [
          IconButton(
            icon: const Icon(Icons.history),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const HistoryScreen()),
              );
            },
          )
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
          child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text("Prénom :", style: TextStyle(fontWeight: FontWeight.bold)),
            TextField(
              controller: _nomController,
              decoration: const InputDecoration(border: OutlineInputBorder()),
            ),
            const SizedBox(height: 20),
            const Text("Problème :", style: TextStyle(fontWeight: FontWeight.bold)),
            DropdownButton<String>(
              isExpanded: true,
              value: _selectedMaladie,
              hint: const Text("Sélectionnez une pathologie"),
              items: typesMaladie.map((m) => DropdownMenuItem(value: m, child: Text(m))).toList(),
              onChanged: (val) => setState(() => _selectedMaladie = val),
            ),
            const SizedBox(height: 20),
            const Text("Zones : touchez le schéma (face ou dos)",
                style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            InteractiveBody(
              selectedZones: _selectedZones,
              onZoneTap: _onZoneTap,
            ),
            if (_selectedZones.isNotEmpty) ...[
              const SizedBox(height: 12),
              Wrap(
                spacing: 6,
                children: _selectedZones
                    .map((z) => Chip(
                          label: Text(z),
                          onDeleted: () => _onZoneTap(z),
                        ))
                    .toList(),
              ),
            ],
            const SizedBox(height: 30),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: (_selectedMaladie == null || _selectedZones.isEmpty)
                    ? null
                    : () => _afficherFiche(context),
                child: const Text("Générer ma fiche"),
              ),
            ),
          ],
          ),
        ),
      ),
    );
  }

  void _afficherFiche(BuildContext context) async {
    String nom = _nomController.text.trim().isEmpty ? "la personne" : _nomController.text.trim();

    await HistoryService.saveEntry(nom, _selectedMaladie!, _selectedZones.join(', '));

    if (!context.mounted) return;

    String priere = (prieres[_selectedMaladie] ?? "").replaceAll("[NOM]", nom);
    final zonesTriees = _selectedZones.toList()..sort();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Fiche : $_selectedMaladie"),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text("Analyse symbolique :", style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              for (final zone in zonesTriees) ...[
                Text(zone, style: const TextStyle(fontWeight: FontWeight.w600)),
                const SizedBox(height: 2),
                Text(genererSynthese(_selectedMaladie!, zone, nom)),
                const SizedBox(height: 12),
              ],
              const Divider(),
              const Text("Prière de soin :", style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 4),
              Text(priere),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text("Fermer"))
        ],
      ),
    );
  }
}
