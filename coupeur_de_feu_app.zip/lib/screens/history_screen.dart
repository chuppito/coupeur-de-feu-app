import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:intl/intl.dart';
import '../models/patient_session.dart';
import '../services/history_service.dart';
import 'home_screen.dart';

class HistoryScreen extends StatelessWidget {
  const HistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Historique des soins")),
      // ValueListenableBuilder écoute directement la box Hive : l'UI se
      // met à jour automatiquement dès qu'une fiche est ajoutée, renommée
      // ou supprimée, sans setState manuel.
      body: SafeArea(
        child: ValueListenableBuilder<Box<PatientSession>>(
        valueListenable: HistoryService.listenable(),
        builder: (context, box, _) {
          final sessions = HistoryService.getHistory();

          if (sessions.isEmpty) {
            return const Center(child: Text("Aucun soin enregistré pour le moment."));
          }

          final grouped = <String, List<PatientSession>>{};
          for (final s in sessions) {
            grouped.putIfAbsent(s.nomPatient, () => []).add(s);
          }

          return ListView(
            padding: const EdgeInsets.only(bottom: 24),
            children: grouped.entries.map((entry) => Card(
              child: ExpansionTile(
                title: Row(children: [
                  Expanded(child: Text(entry.key, style: const TextStyle(fontWeight: FontWeight.bold))),
                  IconButton(
                    icon: const Icon(Icons.edit, size: 18),
                    onPressed: () => _showRenameDialog(context, entry.key),
                  ),
                  IconButton(
                    icon: const Icon(Icons.delete, size: 18, color: Colors.red),
                    onPressed: () => _confirmDelete(context, entry.key),
                  ),
                ]),
                children: [
                  ...entry.value.map((h) => Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            IconButton(
                              tooltip: h.guerie ? "Marquer comme non guéri" : "Marquer comme guéri",
                              icon: Icon(
                                h.guerie ? Icons.check_circle : Icons.check_circle_outline,
                                color: h.guerie ? Colors.green : Colors.grey,
                              ),
                              onPressed: () => HistoryService.toggleGuerison(h),
                            ),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text("${h.maladie} (${h.zone})"),
                                  Text(
                                    DateFormat('dd/MM/yyyy à HH:mm').format(h.date),
                                    style: const TextStyle(fontSize: 12, color: Colors.black54),
                                  ),
                                  if (h.guerie && h.dateGuerison != null)
                                    Text(
                                      "✅ Guéri le ${DateFormat('dd/MM/yyyy à HH:mm').format(h.dateGuerison!)}",
                                      style: const TextStyle(fontSize: 12, color: Colors.green, fontWeight: FontWeight.w600),
                                    ),
                                  if (h.observation.trim().isNotEmpty)
                                    Padding(
                                      padding: const EdgeInsets.only(top: 4),
                                      child: Text(
                                        h.observation,
                                        style: const TextStyle(fontSize: 13, fontStyle: FontStyle.italic),
                                      ),
                                    ),
                                ],
                              ),
                            ),
                            IconButton(
                              tooltip: h.observation.trim().isEmpty ? "Ajouter une note" : "Modifier la note",
                              icon: Icon(
                                h.observation.trim().isEmpty ? Icons.note_add_outlined : Icons.edit_note,
                                size: 20,
                              ),
                              onPressed: () => _showNoteDialog(context, h),
                            ),
                          ],
                        ),
                      )),
                  ListTile(
                    leading: const Icon(Icons.add_circle, color: Colors.blue),
                    title: const Text("Ajouter un nouveau soin"),
                    onTap: () => Navigator.pushAndRemoveUntil(
                      context,
                      MaterialPageRoute(builder: (context) => HomeScreen(prefillNom: entry.key)),
                      (route) => false,
                    ),
                  )
                ],
              ),
            )).toList(),
          );
        },
        ),
      ),
    );
  }

  Future<void> _showNoteDialog(BuildContext context, PatientSession session) async {
    TextEditingController controller = TextEditingController(text: session.observation);
    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Note"),
        content: TextField(
          controller: controller,
          maxLines: 4,
          autofocus: true,
          decoration: const InputDecoration(
            hintText: "Ex : réaction du patient, suivi à prévoir...",
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text("Annuler")),
          TextButton(
            onPressed: () async {
              await HistoryService.updateObservation(session, controller.text.trim());
              if (!context.mounted) return;
              Navigator.pop(context);
            },
            child: const Text("Enregistrer"),
          )
        ],
      ),
    );
  }

  Future<void> _showRenameDialog(BuildContext context, String oldName) async {
    TextEditingController controller = TextEditingController(text: oldName);
    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Renommer le patient"),
        content: TextField(controller: controller),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text("Annuler")),
          TextButton(
            onPressed: () async {
              await HistoryService.renamePatient(oldName, controller.text);
              if (!context.mounted) return;
              Navigator.pop(context);
            },
            child: const Text("Valider"),
          )
        ],
      ),
    );
  }

  void _confirmDelete(BuildContext context, String nom) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Supprimer"),
        content: Text("Supprimer tout l'historique de $nom ?"),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text("Annuler")),
          TextButton(
            onPressed: () async {
              await HistoryService.deletePatient(nom);
              if (!context.mounted) return;
              Navigator.pop(context);
            },
            child: const Text("Supprimer", style: TextStyle(color: Colors.red)),
          )
        ],
      ),
    );
  }
}
