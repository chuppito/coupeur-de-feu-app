import 'package:hive/hive.dart';

part 'patient_session.g.dart'; // Nécessaire pour Hive

@HiveType(typeId: 0)
class PatientSession extends HiveObject {
  @HiveField(0)
  String nomPatient;
  @HiveField(1)
  String zone;
  @HiveField(2)
  String observation;
  @HiveField(3)
  int intensiteAvant;
  @HiveField(4)
  int intensiteApres;
  @HiveField(5)
  DateTime date;
  @HiveField(6)
  String maladie;
  @HiveField(7)
  bool guerie;
  @HiveField(8)
  DateTime? dateGuerison;

  PatientSession({
    required this.nomPatient,
    required this.zone,
    required this.observation,
    required this.intensiteAvant,
    required this.intensiteApres,
    required this.date,
    this.maladie = '',
    this.guerie = false,
    this.dateGuerison,
  });
}
