// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'body_scan.dart';

class BodyScanAdapter extends TypeAdapter<BodyScan> {
  @override
  final int typeId = 3;

  @override
  BodyScan read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++)
        reader.readByte(): reader.read(),
    };
    return BodyScan(
      nomPatient: fields[0] as String? ?? '',
      nomFamille: fields[1] as String? ?? '',
      date: fields[2] as DateTime,
      points: (fields[3] as List?)?.cast<String>() ?? <String>[],
      observation: fields[4] as String? ?? '',
    );
  }

  @override
  void write(BinaryWriter writer, BodyScan obj) {
    writer
      ..writeByte(5)
      ..writeByte(0)
      ..write(obj.nomPatient)
      ..writeByte(1)
      ..write(obj.nomFamille)
      ..writeByte(2)
      ..write(obj.date)
      ..writeByte(3)
      ..write(obj.points)
      ..writeByte(4)
      ..write(obj.observation);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is BodyScanAdapter && runtimeType == other.runtimeType && typeId == other.typeId;
}
