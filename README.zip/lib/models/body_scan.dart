import 'package:hive/hive.dart';

part 'body_scan.g.dart';

@HiveType(typeId: 3)
class BodyScan extends HiveObject {
  @HiveField(0)
  String nomPatient;

  @HiveField(1)
  String nomFamille;

  @HiveField(2)
  DateTime date;

  /// Chaque élément est stocké sous la forme "zone|niveau".
  /// niveaux : aucun, leger, important.
  @HiveField(3)
  List<String> points;

  @HiveField(4)
  String observation;

  BodyScan({
    required this.nomPatient,
    this.nomFamille = '',
    required this.date,
    this.points = const [],
    this.observation = '',
  });

  String get nomComplet =>
      nomFamille.trim().isEmpty ? nomPatient : '$nomPatient ${nomFamille.trim()}';

  int get nombrePoints => points.length;
}
