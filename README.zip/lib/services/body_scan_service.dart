import 'package:flutter/foundation.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../models/body_scan.dart';

class BodyScanService {
  static Box<BodyScan> get _box => Hive.box<BodyScan>('body_scans');

  static ValueListenable<Box<BodyScan>> listenable() => _box.listenable();

  static Future<BodyScan> save({
    required String nomPatient,
    String nomFamille = '',
    required List<String> points,
    String observation = '',
  }) async {
    final scan = BodyScan(
      nomPatient: nomPatient,
      nomFamille: nomFamille,
      date: DateTime.now(),
      points: List<String>.from(points),
      observation: observation,
    );
    await _box.add(scan);
    return scan;
  }

  static List<BodyScan> forPatient(String nomComplet) {
    final list = _box.values.where((s) => s.nomComplet == nomComplet).toList();
    list.sort((a, b) => b.date.compareTo(a.date));
    return list;
  }

  static List<BodyScan> all() {
    final list = _box.values.toList();
    list.sort((a, b) => b.date.compareTo(a.date));
    return list;
  }

  static Future<void> updateObservation(BodyScan scan, String value) async {
    scan.observation = value;
    await scan.save();
  }

  static Future<void> renamePatient(
    String oldNomComplet,
    String newNomPatient,
    String newNomFamille,
  ) async {
    final concernes = _box.values.where((s) => s.nomComplet == oldNomComplet).toList();
    for (final scan in concernes) {
      scan.nomPatient = newNomPatient;
      scan.nomFamille = newNomFamille;
      await scan.save();
    }
  }

  static Future<void> deletePatient(String nomComplet) async {
    final concernes = _box.values.where((s) => s.nomComplet == nomComplet).toList();
    for (final scan in concernes) {
      await scan.delete();
    }
  }
}
