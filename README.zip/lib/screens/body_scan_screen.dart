import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:intl/intl.dart';
import '../models/body_scan.dart';
import '../services/body_scan_service.dart';
import '../services/history_service.dart';

class BodyScanScreen extends StatefulWidget {
  final String? prefillNom;
  final String? prefillNomFamille;

  const BodyScanScreen({super.key, this.prefillNom, this.prefillNomFamille});

  @override
  State<BodyScanScreen> createState() => _BodyScanScreenState();
}

class _BodyScanScreenState extends State<BodyScanScreen> {
  late final TextEditingController _prenomController;
  late final TextEditingController _nomController;
  final Map<String, String> _resultats = {};
  final TextEditingController _observationController = TextEditingController();

  static const _zones = [
    _ScanZone('Tête et cou', Icons.face, 'Balayer derrière la tête puis descendre jusqu’à la base du cou.'),
    _ScanZone('Colonne vertébrale', Icons.accessibility_new, 'De la première cervicale jusqu’au coccyx, en suivant l’axe de la colonne.'),
    _ScanZone('Tronc — côté gauche', Icons.favorite_border, 'Balayer la moitié gauche du tronc, de haut en bas.'),
    _ScanZone('Tronc — côté droit', Icons.favorite_border, 'Balayer la moitié droite du tronc, de haut en bas.'),
    _ScanZone('Bras gauche', Icons.back_hand_outlined, 'De l’épaule jusqu’au bout des doigts.'),
    _ScanZone('Bras droit', Icons.back_hand_outlined, 'De l’épaule jusqu’au bout des doigts.'),
    _ScanZone('Jambe gauche', Icons.directions_walk, 'Du haut de la jambe jusqu’à la pointe du pied.'),
    _ScanZone('Jambe droite', Icons.directions_walk, 'Du haut de la jambe jusqu’à la pointe du pied.'),
  ];

  @override
  void initState() {
    super.initState();
    _prenomController = TextEditingController(text: widget.prefillNom ?? '');
    _nomController = TextEditingController(text: widget.prefillNomFamille ?? '');
  }

  @override
  void dispose() {
    _prenomController.dispose();
    _nomController.dispose();
    _observationController.dispose();
    super.dispose();
  }

  String get _nomComplet {
    final p = _prenomController.text.trim();
    final n = _nomController.text.trim();
    return n.isEmpty ? p : '$p $n';
  }

  Future<void> _scannerZone(_ScanZone zone) async {
    final choix = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 4, 20, 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(zone.nom, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  Text(zone.instruction, style: const TextStyle(color: Colors.black54)),
                  const SizedBox(height: 12),
                  const Text('Après avoir fait le passage avec votre pendule :', style: TextStyle(fontWeight: FontWeight.w600)),
                ],
              ),
            ),
            ListTile(
              leading: const Icon(Icons.check_circle_outline, color: Colors.green),
              title: const Text('RAS — pas de réaction vers le Oui'),
              onTap: () => Navigator.pop(context, 'aucun'),
            ),
            ListTile(
              leading: const Icon(Icons.trending_up),
              title: const Text('Légère orientation vers le Oui'),
              subtitle: const Text('Point de tension léger selon la méthode décrite.'),
              onTap: () => Navigator.pop(context, 'leger'),
            ),
            ListTile(
              leading: const Icon(Icons.rotate_right),
              title: const Text('Rotation vers le Oui'),
              subtitle: const Text('Réaction plus marquée selon la méthode décrite.'),
              onTap: () => Navigator.pop(context, 'important'),
            ),
          ],
        ),
      ),
    );

    if (choix == null || !mounted) return;
    setState(() => _resultats[zone.nom] = choix);
  }

  Future<void> _enregistrer() async {
    if (_nomComplet.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Indiquez au moins le prénom du patient.')));
      return;
    }

    final points = _resultats.entries
        .where((e) => e.value != 'aucun')
        .map((e) => '${e.key}|${e.value}')
        .toList();

    await BodyScanService.save(
      nomPatient: _prenomController.text.trim(),
      nomFamille: _nomController.text.trim(),
      points: points,
      observation: _observationController.text.trim(),
    );

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Scan enregistré : ${points.length} point(s) relevé(s).')),
    );
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final termines = _resultats.length;
    final points = _resultats.values.where((v) => v != 'aucun').length;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Scan du corps'),
        actions: [
          IconButton(
            tooltip: 'Enregistrer le scan',
            onPressed: _resultats.isEmpty ? null : _enregistrer,
            icon: const Icon(Icons.save_outlined),
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(12, 8, 12, 24),
                children: [
                  _buildInfoCard(context),
                  const SizedBox(height: 10),
                  _buildPatientCard(),
                  const SizedBox(height: 10),
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(14),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              const Icon(Icons.checklist, color: Colors.teal),
                              const SizedBox(width: 8),
                              const Expanded(child: Text('Parcours du scan', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17))),
                              Text('$termines/${_zones.length}', style: const TextStyle(fontWeight: FontWeight.bold)),
                            ],
                          ),
                          const SizedBox(height: 4),
                          Text('$points point(s) relevé(s)', style: const TextStyle(fontSize: 12, color: Colors.black54)),
                          const SizedBox(height: 10),
                          for (int i = 0; i < _zones.length; i++) _buildZoneTile(_zones[i], i),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(14),
                      child: TextField(
                        controller: _observationController,
                        maxLines: 4,
                        decoration: const InputDecoration(
                          labelText: 'Observations',
                          hintText: 'Ex. zones à surveiller, remarque du patient…',
                          alignLabelWithHint: true,
                          border: OutlineInputBorder(),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  FilledButton.icon(
                    onPressed: _resultats.isEmpty ? null : _enregistrer,
                    icon: const Icon(Icons.save),
                    label: const Text('Enregistrer le scan'),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoCard(BuildContext context) {
    return Card(
      color: Theme.of(context).colorScheme.secondaryContainer,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              Icon(Icons.info_outline, color: Theme.of(context).colorScheme.onSecondaryContainer),
              const SizedBox(width: 8),
              const Expanded(child: Text('Préparation', style: TextStyle(fontWeight: FontWeight.bold))),
            ]),
            const SizedBox(height: 8),
            const Text('La méthode présentée dans la vidéo consiste à faire rester la personne allongée sur le dos pendant tout le scan et à progresser zone par zone avec le pendule.'),
            const SizedBox(height: 6),
            const Text('Cette fonction enregistre uniquement vos observations au pendule : elle ne mesure pas automatiquement le corps et ne constitue pas un diagnostic médical.', style: TextStyle(fontSize: 12, fontStyle: FontStyle.italic)),
          ],
        ),
      ),
    );
  }

  Widget _buildPatientCard() {
    final noms = HistoryService.getHistory().map((s) => s.nomComplet).toSet().toList()..sort();
    final prefilled = _nomComplet;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Patient', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 10),
            if (noms.isNotEmpty)
              DropdownButtonFormField<String>(
                initialValue: noms.contains(prefilled) ? prefilled : null,
                decoration: const InputDecoration(labelText: 'Choisir un patient existant', border: OutlineInputBorder()),
                items: noms.map((nom) => DropdownMenuItem(value: nom, child: Text(nom))).toList(),
                onChanged: (value) {
                  if (value == null) return;
                  final parts = value.split(' ');
                  setState(() {
                    _prenomController.text = parts.first;
                    _nomController.text = parts.skip(1).join(' ');
                  });
                },
              ),
            if (noms.isNotEmpty) const SizedBox(height: 10),
            Row(
              children: [
                Expanded(child: TextField(controller: _prenomController, decoration: const InputDecoration(labelText: 'Prénom', border: OutlineInputBorder()))),
                const SizedBox(width: 8),
                Expanded(child: TextField(controller: _nomController, decoration: const InputDecoration(labelText: 'Nom', border: OutlineInputBorder()))),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildZoneTile(_ScanZone zone, int index) {
    final resultat = _resultats[zone.nom];
    final label = switch (resultat) {
      'aucun' => 'RAS',
      'leger' => 'Point léger',
      'important' => 'Réaction importante',
      _ => 'À scanner',
    };
    final couleur = switch (resultat) {
      'aucun' => Colors.green,
      'leger' => Colors.orange,
      'important' => Colors.red,
      _ => Colors.black45,
    };

    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
      leading: CircleAvatar(
        backgroundColor: resultat == null ? Colors.black12 : couleur.withOpacity(0.15),
        child: resultat == null ? Text('${index + 1}') : Icon(resultat == 'aucun' ? Icons.check : Icons.priority_high, color: couleur),
      ),
      title: Text(zone.nom, style: const TextStyle(fontWeight: FontWeight.w600)),
      subtitle: Text(resultat == null ? zone.instruction : label, style: TextStyle(color: resultat == null ? Colors.black54 : couleur, fontSize: 12)),
      trailing: FilledButton.tonal(
        onPressed: () => _scannerZone(zone),
        child: Text(resultat == null ? 'Scanner' : 'Modifier'),
      ),
    );
  }
}

class _ScanZone {
  final String nom;
  final IconData icon;
  final String instruction;
  const _ScanZone(this.nom, this.icon, this.instruction);
}

class BodyScansHistory extends StatelessWidget {
  final String nomComplet;
  const BodyScansHistory({super.key, required this.nomComplet});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<Box<BodyScan>>(
      valueListenable: BodyScanService.listenable(),
      builder: (context, box, _) {
        final scans = BodyScanService.forPatient(nomComplet);
        if (scans.isEmpty) return const SizedBox.shrink();
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(16, 8, 16, 4),
              child: Text('Scans du corps', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.teal)),
            ),
            ...scans.map((scan) => ListTile(
                  dense: true,
                  leading: const Icon(Icons.accessibility_new, color: Colors.teal),
                  title: Text('${scan.nombrePoints} point(s) relevé(s)'),
                  subtitle: Text(DateFormat('dd/MM/yyyy à HH:mm').format(scan.date)),
                )),
          ],
        );
      },
    );
  }
}
