import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/services.dart' show rootBundle;
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:path_provider/path_provider.dart';

import '../models/cadran.dart';

/// Gère la bibliothèque de cadrans de radiesthésie.
///
/// Les 9 planches fournies dans assets/pendule_fiches sont installées dans
/// la bibliothèque du Pendule au premier démarrage / lors de la migration.
/// La rubrique « Les chakras » est indépendante et n'est pas modifiée ici.
class CadranService {
  static Box<Cadran> get _box => Hive.box<Cadran>('cadrans');

  static ValueListenable<Box<Cadran>> listenable() => _box.listenable();

  static List<Cadran> getAll() {
    final list = _box.values.toList();
    list.sort((a, b) => a.titre.toLowerCase().compareTo(b.titre.toLowerCase()));
    return list;
  }

  /// Copie l'image choisie (ex: depuis la galerie) dans le stockage propre
  /// à l'app, pour ne pas dépendre du fichier d'origine qui peut être
  /// déplacé ou supprimé par la suite.
  static Future<void> add({required String titre, required File sourceImage}) async {
    final destination = await _copierImage(sourceImage, titre);
    await _box.add(Cadran(
      titre: titre,
      cheminImage: destination.path,
      dateAjout: DateTime.now(),
    ));
  }

  /// Installe une image fournie avec l'application dans le stockage local.
  static Future<void> _addBundledImage({
    required String titre,
    required String asset,
  }) async {
    // Évite de créer des doublons si la migration est relancée.
    if (_box.values.any((c) => c.titre == titre)) return;

    final data = await rootBundle.load(asset);
    final bytes = data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes);
    final destination = await _copierOctets(bytes, titre);

    await _box.add(Cadran(
      titre: titre,
      cheminImage: destination.path,
      dateAjout: DateTime.now(),
      type: 'image',
    ));
  }

  static Future<File> _copierImage(File sourceImage, String titre) async {
    final bytes = await sourceImage.readAsBytes();
    final extension = sourceImage.path.contains('.')
        ? sourceImage.path.split('.').last.toLowerCase()
        : 'png';
    return _copierOctets(bytes, titre, extension: extension);
  }

  static Future<File> _copierOctets(
    Uint8List bytes,
    String titre, {
    String extension = 'png',
  }) async {
    final dir = await getApplicationDocumentsDirectory();
    final cadransDir = Directory('${dir.path}/cadrans');
    if (!await cadransDir.exists()) {
      await cadransDir.create(recursive: true);
    }

    final nomSecurise = titre
        .toLowerCase()
        .replaceAll(RegExp(r'[^a-z0-9]+'), '_')
        .replaceAll(RegExp(r'_+'), '_')
        .replaceAll(RegExp(r'^_|_$'), '');
    final nomFichier = 'cadran_${nomSecurise}_${DateTime.now().microsecondsSinceEpoch}.$extension';
    final destination = File('${cadransDir.path}/$nomFichier');
    await destination.writeAsBytes(bytes, flush: true);
    return destination;
  }

  /// Crée un cadran « éventail » dessiné nativement.
  static Future<void> addEventail({
    required String titre,
    required List<String> labels,
    String? attribution,
    List<String>? groupes,
  }) async {
    await _box.add(Cadran(
      titre: titre,
      dateAjout: DateTime.now(),
      type: 'eventail',
      labels: labels,
      attribution: attribution,
      groupes: groupes,
    ));
  }

  /// Modifie un cadran « éventail » existant.
  static Future<void> updateEventail(
    Cadran cadran, {
    required String titre,
    required List<String> labels,
    String? attribution,
    List<String>? groupes,
  }) async {
    cadran.titre = titre;
    cadran.labels = labels;
    cadran.attribution = attribution;
    cadran.groupes = groupes;
    await cadran.save();
  }

  static Future<void> delete(Cadran cadran) async {
    if (cadran.cheminImage.trim().isNotEmpty) {
      final fichier = File(cadran.cheminImage);
      if (await fichier.exists()) {
        await fichier.delete();
      }
    }
    await cadran.delete();
  }

  // ---------------------------------------------------------------------
  // Pré-remplissage / migration des cadrans du Pendule.
  // ---------------------------------------------------------------------

  static const String _cleVersion = 'cadrans_seed_version';
  static const int _versionActuelle = 4;

  /// Remplace les anciens cadrans « éventail » codés en dur par les 9
  /// planches image fournies dans assets/pendule_fiches.
  ///
  /// Les cadrans ajoutés manuellement par l'utilisateur sont conservés.
  /// La rubrique « Les chakras » n'est pas concernée par cette migration.
  static Future<void> seedNouveautesSiNecessaire() async {
    final meta = Hive.box('app_meta');
    final version = (meta.get(_cleVersion) as int?) ?? 0;

    if (version >= _versionActuelle) return;

    // Titres des anciennes planches créées nativement par le code du
    // Pendule. On ne supprime que ces entrées connues, jamais la bibliothèque
    // personnelle de l'utilisateur.
    const anciensTitres = <String>{
      'Augmenter le taux vibratoire',
      'Planche de contrôle',
      'Pourcentages',
      'Chiffres',
      'Intensité',
      'Jours / mois',
      'Les 7 chakras',
      'Lettres',
      'Énergétique des chakras',
      'Sécurité (Oui/Non)',
      'Origines subtiles des problèmes',
      'Origines des problèmes (bâtiment)',
      "Planche d'erreur",
    };

    for (final cadran in _box.values.toList()) {
      if (anciensTitres.contains(cadran.titre)) {
        await cadran.delete();
      }
    }

    const fiches = <({String titre, String asset})>[
      (
        titre: 'Planche des origines subtiles des problèmes dans une maison',
        asset: 'assets/pendule_fiches/5e930180cb4bb_Capturedcran2020-04-1213.41.01.png',
      ),
      (
        titre: 'Planche des origines des problèmes dans une maison',
        asset: 'assets/pendule_fiches/5e93018f005da_Capturedcran2020-04-1213.40.40.png',
      ),
      (
        titre: 'Planche des taux vibratoires, en Unité Bovis logarithmique',
        asset: 'assets/pendule_fiches/5e9301b8a58e5_Capturedcran2020-04-1213.39.43.png',
      ),
      (
        titre: 'Planche énergétique des chakras',
        asset: 'assets/pendule_fiches/5e9301d14e975_Capturedcran2020-04-1213.39.16.png',
      ),
      (
        titre: 'Planche des pourcentages',
        asset: 'assets/pendule_fiches/5e9301626b56f_Capturedcran2020-04-1213.41.55.png',
      ),
      (
        titre: 'Planche des chakras personnels',
        asset: 'assets/pendule_fiches/5e9301c47fde6_Capturedcran2020-04-1213.39.32.png',
      ),
      (
        titre: 'Planche du subtil individuel',
        asset: 'assets/pendule_fiches/5e93019d34b8d_Capturedcran2020-04-1213.40.18.png',
      ),
      (
        titre: 'Planche des taux vibratoires, en Unité Bovis',
        asset: 'assets/pendule_fiches/5e9301ab5d8d0_Capturedcran2020-04-1213.40.01.png',
      ),
      (
        titre: 'Planche des affinités',
        asset: 'assets/pendule_fiches/5e93017168cec_Capturedcran2020-04-1213.41.30.png',
      ),
    ];

    for (final fiche in fiches) {
      await _addBundledImage(titre: fiche.titre, asset: fiche.asset);
    }

    await meta.put(_cleVersion, _versionActuelle);
  }
}
